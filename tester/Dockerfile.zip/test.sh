#!/bin/bash
dig guarddutyc2activityb.com